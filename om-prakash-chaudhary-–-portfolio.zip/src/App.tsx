/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';

interface CodeSnippetPart {
  type: '' | 'k' | 'c';
  text: string;
}

interface DemoItem {
  tab: string;
  code: [string, string][];
  out: string;
}

interface ProjectItem {
  n: string;
  s: string;
  st: string;
  live: number;
  d: string[];
  t: string;
  url?: string;
  githubUrl?: string;
  scaleMetric?: string;
}

interface TierItem {
  u: number;
  l: string;
  t: string[];
}

const demos: DemoItem[] = [
  {
    tab: 'REST endpoint',
    code: [
      ['c', '// WordPress: custom REST route'],
      ['', 'add_action( '],
      ['k', "'rest_api_init'"],
      ['', ', function () {'],
      ['', '  register_rest_route( '],
      ['k', "'demo/v1'"],
      ['', ', '],
      ['k', "'/projects'"],
      ['', ', ['],
      ['', '    '],
      ['k', "'callback'"],
      ['', ' => '],
      ['k', "'get_projects'"],
      ['', ','],
      ['', '    '],
      ['k', "'permission_callback'"],
      ['', ' => '],
      ['k', "'__return_true'"],
      ['', '  ] );'],
      ['', '} );'],
    ],
    out: 'GET /wp-json/demo/v1/projects\n200 OK\n{ "projects": 5, "status": "ok" }',
  },
  {
    tab: 'Signed webhook',
    code: [
      ['c', '// Sign the payload before delivery'],
      ['', '$body = wp_json_encode( $event );'],
      ['', '$sig  = hash_hmac( '],
      ['k', "'sha256'"],
      ['', ', $body, $secret );'],
      ['', 'wp_remote_post( $url, ['],
      ['', '  '],
      ['k', "'headers'"],
      ['', ' => [ '],
      ['k', "'X-Signature'"],
      ['', ' => $sig ],'],
      ['', '  '],
      ['k', "'timeout'"],
      ['', ' => 5,'],
      ['', '] );'],
    ],
    out: 'POST https://partner.example/hook\nX-Signature: 9f2c…e41a\n202 Accepted · attempt 1 of 3',
  },
  {
    tab: 'AI gateway',
    code: [
      ['c', '// Check permission, then call the AI API'],
      ['', 'check_ajax_referer( '],
      ['k', "'ai_nonce'"],
      ['', ' );'],
      ['', 'if ( ! current_user_can( '],
      ['k', "'edit_posts'"],
      ['', ' ) ) wp_die();'],
      ['', '$prompt = sanitize_text_field( $_POST['],
      ['k', "'prompt'"],
      ['', '] );'],
      ['', '$res = wp_remote_post( $api_url, $args );'],
    ],
    out: 'nonce: valid\ncapability: edit_posts ✓\nprompt sanitized · quota 12/50\n200 OK · response validated',
  },
];

const projects: ProjectItem[] = [
  {
    n: 'Canvasroom',
    s: 'Live 3D & AI Room Presentation Platform · canvasroom.space',
    st: 'Live platform',
    live: 1,
    url: 'https://canvasroom.space',
    scaleMetric: 'Live 3D · Auto Voice Agent · Unlimited Video',
    d: [
      'Built for Interior Designers, Wallpaper Dealers, and Real Estate Project Presentations to showcase spaces in interactive live 3D.',
      'Unlimited 3D video rendering powered by an autonomous Auto Voice Agent that explains interior and exterior architectural elements.',
      'Room scanning feature allowing users to scan and virtually install/arrange furniture directly inside the 3D room.',
      'Interactive room configuration with real-time wallpaper, material, lighting, and layout customizations.',
      'Live in production at canvasroom.space.',
    ],
    t: 'Three.js · WebGL · 3D Spatial Presentation · Auto Voice Agent · Video Rendering Engine',
  },
  {
    n: 'Bingotingo',
    s: 'High-traffic digital platform · bingotingo.mahashankh.org',
    st: 'Live website',
    live: 1,
    url: 'https://bingotingo.mahashankh.org',
    scaleMetric: 'Scaled to 1 Million Users in 2025',
    d: [
      'Scaled to 1 Million users in 2025 with zero-downtime architecture and high-performance server tuning.',
      'Full-stack WordPress & PHP deployment with custom caching layers, database indexing, and CDN integration.',
      'End-to-end engineered, designed, and deployed for massive concurrent visitor loads.',
      'Live in production at bingotingo.mahashankh.org.',
    ],
    t: 'WordPress · PHP · MySQL · CDN · 1M Users Scalability',
  },
  {
    n: 'AJUPY AI',
    s: 'Image Generative AI Platform · ajupy.com',
    st: 'Live platform',
    live: 1,
    url: 'https://ajupy.com',
    scaleMetric: 'Generated 5 Lakhs in 1st 6 Months',
    d: [
      'Image Generative AI platform: generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.',
      'Generative AI interfaces and visual-content workflows (text-to-image, style adaptation, and fashion AI use cases).',
      'Asynchronous job queue processing, rate limiting, subscription usage tracking, and API resilience.',
      'Live in production at ajupy.com.',
    ],
    t: 'React · TypeScript · Generative AI APIs · Textile Industry AI Workflows',
  },
  {
    n: 'SpotlightXO',
    s: 'Creator & talent discovery platform · spotlightxo.com',
    st: 'Live platform',
    live: 1,
    url: 'https://spotlightxo.com',
    d: [
      'Next-generation talent spotlight and creator discovery platform.',
      'Interactive creator portfolios, dynamic media presentation, and audience engagement mechanics.',
      'High-performance modern frontend architecture with responsive design, search, and cloud deployment.',
      'Live at spotlightxo.com.',
    ],
    t: 'React · TypeScript · Cloud Infrastructure · Digital Media',
  },
  {
    n: 'WordPress AI Integration Plugin',
    s: 'Secure AI gateway & model connector for WordPress',
    st: 'Open Source',
    live: 1,
    url: 'https://github.com/opspj007',
    githubUrl: 'https://github.com/opspj007',
    d: [
      'Secure AI gateway plugin connecting WordPress with LLM & generative AI model APIs.',
      'Admin settings, encrypted API-key storage, nonce & capability verification, and sanitized inputs.',
      'Token usage logging, rate limits, quota enforcement, and comprehensive PHPUnit test suites.',
      'Open source repository and documentation hosted on GitHub.',
    ],
    t: 'PHP · WordPress HTTP API · MySQL · PHPUnit · GitHub Actions',
  },
  {
    n: '3D Home & Wallpaper Presenter Studio',
    s: 'Interactive room visualization for retailers and designers',
    st: 'Product concept',
    live: 1,
    d: [
      'Room visualization and interior presentation workflows.',
      'Wallpaper and furniture presentation, interactive room configuration.',
      'Walkthrough and video presentation, plus AI-assisted design guidance.',
    ],
    t: 'Web app · 3D interface · media workflows',
  },
  {
    n: 'Saree Designer AI',
    s: 'Digital fashion design workflow',
    st: 'Product initiative',
    live: 1,
    d: [
      'Saree and textile design workflows.',
      'AI-assisted creative concepts and design previews.',
      'Export and production-workflow planning.',
    ],
    t: 'Web interfaces · AI integration · image processing',
  },
  {
    n: 'EventBridge Webhook Plugin',
    s: 'Reliable event-driven WordPress integrations',
    st: 'In progress',
    live: 0,
    githubUrl: 'https://github.com/opspj007',
    d: [
      'Configurable event subscriptions and webhook endpoints.',
      'HMAC request signing, retries and delivery history.',
      'Failure reporting and tests for success, failure and invalid responses.',
    ],
    t: 'PHP · WordPress hooks · REST API · PHPUnit · GitHub Actions',
  },
];

interface SkillGroup {
  category: string;
  skills: string[];
}

interface DeveloperTrack {
  id: 'wordpress' | 'ai';
  title: string;
  badge: string;
  tagline: string;
  description: string;
  milestone: string;
  groups: SkillGroup[];
}

const wordpressDeveloperTrack: DeveloperTrack = {
  id: 'wordpress',
  title: 'WordPress Developer',
  badge: 'WordPress & PHP Specialist',
  tagline: 'Custom Plugins, Themes, High-Concurrency PHP & Database Architecture',
  description:
    '6+ years of commercial production experience (Mahashankh Design & Technology, 2019–2025). Proven expertise architecting custom plugins, complex themes, secure REST APIs, and scaling platforms to 1 Million registered users.',
  milestone: '⚡ 1 Million Users Scaled in 2025 (Bingotingo)',
  groups: [
    {
      category: 'Core WordPress Architecture',
      skills: [
        'Custom Plugin Development',
        'Custom Theme Development',
        'Hooks, Actions & Filters API',
        'Custom Post Types & Taxonomies',
        'Gutenberg Blocks Development',
        'Settings API & Options Framework',
        'WP_Query & Loop Optimization',
        'Roles, Capabilities & Nonce Security',
        'Custom REST API Endpoints',
        'Non-blocking AJAX Handling',
      ],
    },
    {
      category: 'PHP & Backend Systems',
      skills: [
        'PHP 7.x & PHP 8.x',
        'Object-Oriented Programming (OOP)',
        'Composer Dependency Management',
        'WordPress HTTP API (wp_remote_post/get)',
        'Webhook Endpoints & HMAC Signing',
        'Error Handling & Logging (WP_DEBUG)',
        'Form Validation & Request Pipelines',
      ],
    },
    {
      category: 'Database & High-Traffic Scaling',
      skills: [
        'MySQL Schema Design & Optimization',
        '$wpdb Prepared Statements',
        'SQL Indexing & Hot Query Tuning',
        'Page Caching & Edge Cache Purging',
        'Object Caching (Redis / Memcached)',
        'CDN Static Asset Offloading (Cloudflare)',
        'Zero-Downtime Deployment & Migrations',
      ],
    },
    {
      category: 'Security & Quality Assurance',
      skills: [
        'Input Sanitization (sanitize_text_field)',
        'Output Escaping (esc_html, esc_attr, esc_url)',
        'CSRF & SQL Injection Protection',
        'PHPUnit Automated Testing',
        'GitHub Actions CI/CD for Plugins',
        'Lighthouse Speed Optimization',
      ],
    },
  ],
};

const aiDeveloperTrack: DeveloperTrack = {
  id: 'ai',
  title: 'AI Developer',
  badge: 'Generative AI & Modern Web',
  tagline: 'Generative AI Pipelines, Model Gateways, TypeScript & Platform Engineering',
  description:
    'Founder at AJUPY AI (2025–Present). Hands-on experience engineering image generative AI platforms, visual workflows, high-throughput queue systems, and model failovers; generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.',
  milestone: '⚡ Generated 5 Lakhs in 1st 6 Months with Major Textile Clients',
  groups: [
    {
      category: 'Generative AI & LLM Systems',
      skills: [
        'LLM APIs & Model Integration',
        'Google Gemini API (@google/genai)',
        'Text-to-Image Generation Pipelines',
        'Fashion AI & Visual Workflows',
        'Structured Outputs (JSON Schema)',
        'Prompt Engineering & System Directives',
        'Multi-Model Fallbacks & Routing',
      ],
    },
    {
      category: 'AI Platform Architecture & Scale',
      skills: [
        'Asynchronous Inference Task Queues',
        'Model API Rate Limiting & Quotas',
        'Token & Credit Usage Accounting',
        'Streaming Responses & Typewriter UI',
        'Media Processing & Image CDN Offloading',
        'Long-running Task Webhook Callbacks',
      ],
    },
    {
      category: 'Modern Full-Stack & Frontend',
      skills: [
        'React 19 & TypeScript',
        'SPA Architecture & Custom Hooks',
        'Node.js & Express API Gateways',
        'Tailwind CSS & Modern Responsive Design',
        'HTML5 Canvas (Neural Networks & Visuals)',
        'RESTful API Architecture',
        'Accessibility (WCAG 2.1) & UI Polish',
      ],
    },
    {
      category: 'AI Safety, Security & Cloud Ops',
      skills: [
        'Nonce-Protected AI Gateway Proxies',
        'Prompt Sanitization & Content Moderation',
        'API Key Vaulting & Environment Secrets',
        'Token Cost Guardrails & Usage Caps',
        'Cloud Run & Container Workflows',
        'Git & GitHub Automation',
      ],
    },
  ],
};

const skillsData: Record<string, string[]> = {
  'WordPress Core': wordpressDeveloperTrack.groups[0].skills,
  'PHP & Backend': wordpressDeveloperTrack.groups[1].skills,
  'Database & Scale': wordpressDeveloperTrack.groups[2].skills,
  'Security & Testing': wordpressDeveloperTrack.groups[3].skills,
  'Generative AI & LLMs': aiDeveloperTrack.groups[0].skills,
  'AI Platform & Queues': aiDeveloperTrack.groups[1].skills,
  'Frontend & Full-Stack': aiDeveloperTrack.groups[2].skills,
  'AI Safety & Cloud': aiDeveloperTrack.groups[3].skills,
};

const tiers: TierItem[] = [
  {
    u: 1000,
    l: '1,000',
    t: ['One server with page caching', 'MySQL with the right indexes', 'Compressed, lazy-loaded images'],
  },
  {
    u: 10000,
    l: '10,000',
    t: ['CDN for static files and images', 'Object cache to cut repeat queries', 'Error logging and uptime alerts'],
  },
  {
    u: 100000,
    l: '100,000',
    t: [
      'Separate database server with a read replica',
      'Full-page caching at the edge',
      'Background queue for emails, webhooks and AI calls',
    ],
  },
  {
    u: 500000,
    l: '500,000',
    t: [
      'Several app servers behind a load balancer',
      'Media in shared object storage',
      'Rate limiting, retries and monitoring dashboards',
    ],
  },
  {
    u: 1000000,
    l: '1,000,000',
    t: [
      'Autoscaling app tier and CDN-first delivery',
      'Partition heavy tables; tune or split hot queries',
      'Event pipeline for async work, load-tested with clear SLOs',
    ],
  },
];

const rolesList = [
  'WordPress Developer',
  'PHP Developer',
  'Backend Developer',
  'Web Application Developer',
  'WordPress Plugin Engineer',
  'Full-Stack Developer',
  'AI Application Developer',
  'Software Engineer, Web Platforms',
];

function generateResumeHTML(): string {
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Om Prakash Chaudhary – Resume</title><style>body{font:15px/1.55 Georgia,serif;max-width:780px;margin:32px auto;padding:0 20px;color:#14204a}h1{margin:0;font-size:30px}h2{font-size:17px;border-bottom:2px solid #e8930c;padding-bottom:3px;margin:22px 0 8px}ul{margin:4px 0;padding-left:20px}.s{color:#55608a}@media print{body{margin:0}}</style></head><body>` +
    `<h1>Om Prakash Chaudhary</h1><div class="s">WordPress &amp; PHP Engineer · AI Application Developer · Founder at AJUPY AI<br>opspj007@gmail.com · github.com/opspj007 · linkedin.com/in/om-prakash-chaudhary-nims · opchaudhary.online · India, open to relocation</div>` +
    `<h2>Summary</h2><p>Software developer and product builder with hands-on experience in WordPress and PHP development, web applications, API integration and AI-powered solutions. Founder at AJUPY AI (2025 – present: generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries). Proven track record scaling platforms to 1 Million users (Bingotingo in 2025). Looking to join an engineering team and grow as a software engineer.</p>` +
    `<h2>Experience &amp; Timeline</h2>` +
    `<b>Founder, AJUPY AI</b> <span class="s">2025 – present</span><ul><li>Leading technical architecture and development of image generative AI platform (ajupy.com); generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.</li><li>Architected AI model pipelines, high-throughput asynchronous job queues, and subscription workflows.</li></ul>` +
    `<b>Technology Product Developer, Mahashankh Design &amp; Technology</b> <span class="s">2019 – 2025</span><ul><li>Built and improved WordPress websites and digital platforms, including custom functionality and API integrations.</li><li>Scaled web platforms including Bingotingo to 1 Million registered users in 2025.</li><li>Translated business requirements into technical plans; troubleshooting, database optimization, and deployment.</li></ul>` +
    `<h2>Projects</h2><ul><li><b>Bingotingo (bingotingo.mahashankh.org)</b>: High-traffic platform scaled to 1 Million users in 2025.</li><li><b>AJUPY AI (ajupy.com)</b>: Image Generative AI application platform — generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.</li><li><b>Canvasroom (canvasroom.space)</b>: Live 3D presentation platform for interior designers, wallpaper dealers &amp; real estate with unlimited video rendering, auto voice agent walkthroughs, and room furniture installation.</li><li><b>SpotlightXO (spotlightxo.com)</b>: Creator and talent discovery platform.</li><li><b>WordPress AI Integration Plugin</b>: Secure open-source AI gateway for WordPress (github.com/opspj007).</li><li>3D Home &amp; Wallpaper Presenter Studio and Saree Designer AI: visualization and design workflows.</li><li>EventBridge Webhook Plugin: in progress (PHP, REST API, PHPUnit).</li></ul>` +
    `<h2>Skills &amp; Specializations</h2>` +
    `<p><b>💻 WordPress Developer:</b> Custom plugins &amp; themes, hooks &amp; filters, custom post types, Gutenberg blocks, REST API, Settings API, PHP 7/8, OOP, MySQL prepared statements, SQL optimization, Redis/Memcached object cache, CDN edge caching &amp; 1M user scaling.</p>` +
    `<p><b>🤖 AI Developer:</b> LLM APIs, Google Gemini API, text-to-image generation pipelines, fashion AI workflows, prompt engineering, structured JSON outputs, async inference queues, token quota limits, React 19, TypeScript, Node.js/Express, AI safety &amp; textile industry commercial AI workflows.</p>` +
    `<h2>Education</h2><p>B.Tech, Computer Science Engineering, NIMS University, Jaipur (2022 – 2026)</p></body></html>`;
}

export default function App() {
  // Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Resume dropdown
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const resumeMenuRef = useRef<HTMLDivElement>(null);

  // Resume download status note
  const [downloadNote, setDownloadNote] = useState('');

  // Interactive console state
  const [curDemo, setCurDemo] = useState(0);
  const [consoleOut, setConsoleOut] = useState('');
  const [consoleHint, setConsoleHint] = useState('Pick a tab, then run it.');
  const consoleTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Project expansion state
  const [openProjects, setOpenProjects] = useState<Record<number, boolean>>({});

  // Scale slider state
  const [scaleTierIndex, setScaleTierIndex] = useState(0);

  // Developer track filter ('both' | 'wordpress' | 'ai')
  const [activeDevTrack, setActiveDevTrack] = useState<'both' | 'wordpress' | 'ai'>('both');

  // Copy email state
  const [copyEmailText, setCopyEmailText] = useState('Copy email');

  // Message form state
  const [messageName, setMessageName] = useState('');
  const [messageEmail, setMessageEmail] = useState('');
  const [messageText, setMessageText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [messageError, setMessageError] = useState('');
  const [submittedInfo, setSubmittedInfo] = useState<{
    name: string;
    email: string;
    message: string;
    timestamp: string;
  } | null>(null);

  // Neural canvas background ref
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Initialize theme on mount
  useEffect(() => {
    const isDark =
      document.documentElement.dataset.theme === 'dark' ||
      (!document.documentElement.dataset.theme && window.matchMedia('(prefers-color-scheme: dark)').matches);
    const initial = isDark ? 'dark' : 'light';
    setTheme(initial);
    document.documentElement.dataset.theme = initial;
  }, []);

  // Theme toggle function
  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    document.documentElement.dataset.theme = nextTheme;
  };

  // Close resume dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (resumeMenuRef.current && !resumeMenuRef.current.contains(e.target as Node)) {
        setIsResumeOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Code console: tab change
  const handleSelectTab = (index: number) => {
    if (consoleTimerRef.current) {
      clearInterval(consoleTimerRef.current);
      consoleTimerRef.current = null;
    }
    setCurDemo(index);
    setConsoleOut('');
    setConsoleHint('Pick a tab, then run it.');
  };

  // Code console: run request
  const handleRunRequest = () => {
    if (consoleTimerRef.current) {
      clearInterval(consoleTimerRef.current);
      consoleTimerRef.current = null;
    }
    const fullText = demos[curDemo].out;
    setConsoleOut('');
    setConsoleHint('Running…');

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      setConsoleOut(fullText);
      setConsoleHint('Done. (Simulated response)');
      return;
    }

    let charIndex = 0;
    consoleTimerRef.current = setInterval(() => {
      charIndex += 2;
      setConsoleOut(fullText.slice(0, charIndex));
      if (charIndex >= fullText.length) {
        if (consoleTimerRef.current) {
          clearInterval(consoleTimerRef.current);
          consoleTimerRef.current = null;
        }
        setConsoleHint('Done. (Simulated response)');
      }
    }, 22);
  };

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (consoleTimerRef.current) {
        clearInterval(consoleTimerRef.current);
      }
    };
  }, []);

  // Download resume action
  const handleDownloadResume = () => {
    try {
      const html = generateResumeHTML();
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Om-Prakash-Chaudhary-Resume.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setDownloadNote('Resume downloaded. Open it and use Print to make a PDF.');
    } catch {
      setDownloadNote("Download isn't available in this view. Email opspj007@gmail.com for the resume.");
    }
  };

  // Toggle project accordion
  const toggleProject = (index: number) => {
    setOpenProjects((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  // Copy email action
  const handleCopyEmail = async () => {
    const emailToCopy = 'opspj0001@gmail.com';
    try {
      await navigator.clipboard.writeText(emailToCopy);
      setCopyEmailText('Email copied');
      setTimeout(() => {
        setCopyEmailText('Copy email');
      }, 1800);
    } catch {
      setCopyEmailText(emailToCopy);
    }
  };

  // Send message submission handler
  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const n = messageName.trim();
    const eMail = messageEmail.trim();
    const m = messageText.trim();

    if (!n) {
      setMessageError('Please enter your name.');
      return;
    }
    if (!eMail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(eMail)) {
      setMessageError('Please provide a valid email address.');
      return;
    }
    if (!m) {
      setMessageError('Please enter your message.');
      return;
    }

    setMessageError('');
    setIsSubmitting(true);

    setTimeout(() => {
      const newEntry = {
        name: n,
        email: eMail,
        message: m,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      try {
        const existing = JSON.parse(localStorage.getItem('portfolio_submissions') || '[]');
        localStorage.setItem('portfolio_submissions', JSON.stringify([...existing, newEntry]));
      } catch {
        // Fallback if localStorage is restricted
      }

      setSubmittedInfo(newEntry);
      setIsSubmitting(false);
      setIsSubmitted(true);
      setMessageName('');
      setMessageEmail('');
      setMessageText('');
    }, 550);
  };

  // Animated neural network canvas
  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const cx = cv.getContext('2d');
    if (!cx) return;

    let animId: number;
    let W = window.innerWidth;
    let H = window.innerHeight;
    let pts: Array<{ x: number; y: number; vx: number; vy: number; r: number }> = [];
    let mx = -999;
    let my = -999;
    let acc = '#e8930c';
    let ink = '#14204a';
    let frameCount = 0;
    const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const colors = () => {
      const s = getComputedStyle(document.documentElement);
      acc = s.getPropertyValue('--accent').trim() || acc;
      ink = s.getPropertyValue('--ink').trim() || ink;
    };

    const size = () => {
      const d = Math.min(window.devicePixelRatio || 1, 2);
      W = window.innerWidth;
      H = window.innerHeight;
      cv.width = W * d;
      cv.height = H * d;
      cx.setTransform(d, 0, 0, d, 0, 0);

      const n = Math.min(90, Math.round((W * H) / 17000));
      pts = [];
      for (let i = 0; i < n; i++) {
        pts.push({
          x: Math.random() * W,
          y: Math.random() * H,
          vx: (Math.random() - 0.5) * 0.35,
          vy: (Math.random() - 0.5) * 0.35,
          r: 1.2 + Math.random() * 1.6,
        });
      }
      colors();
    };

    const frame = () => {
      if (frameCount++ % 45 === 0) colors();
      cx.clearRect(0, 0, W, H);
      const L = Math.min(150, W / 6);

      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        if (!still) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < 0 || p.x > W) p.vx *= -1;
          if (p.y < 0 || p.y > H) p.vy *= -1;
        }

        for (let j = i + 1; j < pts.length; j++) {
          const q = pts[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < L) {
            cx.globalAlpha = (1 - dist / L) * 0.22;
            cx.strokeStyle = ink;
            cx.lineWidth = 1;
            cx.beginPath();
            cx.moveTo(p.x, p.y);
            cx.lineTo(q.x, q.y);
            cx.stroke();
          }
        }

        const md = Math.hypot(p.x - mx, p.y - my);
        if (md < L * 1.4) {
          cx.globalAlpha = (1 - md / (L * 1.4)) * 0.6;
          cx.strokeStyle = acc;
          cx.beginPath();
          cx.moveTo(p.x, p.y);
          cx.lineTo(mx, my);
          cx.stroke();
        }

        cx.globalAlpha = 0.55;
        cx.fillStyle = md < L * 1.4 ? acc : ink;
        cx.beginPath();
        cx.arc(p.x, p.y, p.r, 0, 6.283);
        cx.fill();
      }

      cx.globalAlpha = 1;
      if (!still) {
        animId = requestAnimationFrame(frame);
      }
    };

    const handleResize = () => {
      size();
      if (still) frame();
    };

    const handlePointerMove = (e: PointerEvent) => {
      mx = e.clientX;
      my = e.clientY;
    };

    const handlePointerLeave = () => {
      mx = -999;
      my = -999;
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    window.addEventListener('pointerleave', handlePointerLeave);

    size();
    frame();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerleave', handlePointerLeave);
      if (animId) cancelAnimationFrame(animId);
    };
  }, [theme]);

  // Current tier for scale section
  const currentTier = tiers[scaleTierIndex];
  const progressPercent = ((Math.log10(currentTier.u) - 2) / 4) * 100;



  return (
    <>
      <canvas id="ai-bg" ref={canvasRef} aria-hidden="true" />

      {/* Header */}
      <header className="nav">
        <div className="wrap">
          <a className="logo" href="#top">
            Om Prakash Chaudhary
          </a>
          <a className="l" href="#work">
            Projects
          </a>
          <a className="l" href="#scale">
            Scale
          </a>
          <a className="l" href="#timeline">
            Timeline
          </a>
          <a className="l" href="#skills">
            Skills
          </a>
          <a className="l" href="#about">
            About
          </a>
          <a className="l" href="#contact">
            Contact
          </a>

          {/* Resume dropdown */}
          <div className="resume-menu" ref={resumeMenuRef}>
            <button
              className="icon-btn dl"
              id="resumeBtn"
              aria-expanded={isResumeOpen}
              onClick={() => setIsResumeOpen(!isResumeOpen)}
            >
              Download Resume ▾
            </button>

            {isResumeOpen && (
              <div className="resume-dropdown" id="resumeDropdown">
                <a
                  href="https://drive.google.com/drive/folders/178kwOutYGuJMlUEQnUrTX3wt78-eBIKo?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResumeOpen(false)}
                >
                  🤖 AI Developer Resume
                </a>

                <a
                  href="https://drive.google.com/drive/folders/1XGBLR8paHLZmILGpPOadrA0-08pJTmm8?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResumeOpen(false)}
                >
                  💻 WordPress Developer Resume
                </a>
              </div>
            )}
          </div>

          {/* Theme button */}
          <button className="icon-btn" id="theme" aria-label="Toggle light and dark theme" onClick={toggleTheme}>
            Theme
          </button>
        </div>
      </header>

      {/* Main content */}
      <main id="top">
        {/* Hero Section */}
        <section className="hero">
          <div className="wrap hero-grid">
            <div>
              <h1>I build web platforms and AI features that work.</h1>
              <p className="lead">
                WordPress and PHP engineer, B.Tech Computer Science (NIMS University, Jaipur, class of 2026),
                Founder at AJUPY AI (2025 – Present), formerly at Mahashankh Design &amp; Technology (2019 – 2025). Open to roles across India.
              </p>
              <div className="cta">
                <a className="btn p" href="#work">
                  See my projects
                </a>
                <button className="btn dl" onClick={handleDownloadResume}>
                  Download resume
                </button>
                <a className="btn" href="#contact">
                  Get in touch
                </a>
              </div>
              {downloadNote && (
                <p className="stack dlnote" role="status" style={{ margin: '12px 0 0' }}>
                  {downloadNote}
                </p>
              )}
            </div>

            {/* Code Console */}
            <div className="console" aria-label="Interactive code demo">
              <div className="tabs" role="tablist" id="tabs">
                {demos.map((d, i) => (
                  <button
                    key={d.tab}
                    role="tab"
                    aria-selected={curDemo === i}
                    onClick={() => handleSelectTab(i)}
                  >
                    {d.tab}
                  </button>
                ))}
              </div>
              <pre className="code" id="code">
                {demos[curDemo].code.map((p, i) => {
                  const nextPart = demos[curDemo].code[i + 1];
                  const shouldBreak =
                    p[1] === '' ||
                    /[;{}\]]\s*$/.test(p[1]) ||
                    p[0] === 'c' ||
                    i === demos[curDemo].code.length - 1;
                  return (
                    <React.Fragment key={i}>
                      <span className={p[0] || undefined}>{p[1]}</span>
                      {shouldBreak && '\n'}
                    </React.Fragment>
                  );
                })}
              </pre>
              <div className="runbar">
                <button className="run" id="run" onClick={handleRunRequest}>
                  Run request
                </button>
                <span className="hint" id="hint">
                  {consoleHint}
                </span>
              </div>
              <pre className="out" id="out" aria-live="polite">
                {consoleOut}
              </pre>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="work">
          <div className="wrap">
            <h2>Projects</h2>
            <div className="grid" id="projects">
              {projects.map((p, i) => {
                const isOpen = !!openProjects[i];
                return (
                  <div key={p.n} className="proj" data-open={isOpen ? 'true' : 'false'}>
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      aria-controls={`d${i}`}
                      onClick={() => toggleProject(i)}
                    >
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                          <h3>{p.n}</h3>
                          {p.scaleMetric && <span className="scale-pill">⚡ {p.scaleMetric}</span>}
                        </div>
                        <div className="sub">{p.s}</div>
                      </div>
                      <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                        <span className={`badge${p.live ? ' live' : ''}`}>{p.st}</span>
                        <span className="caret" aria-hidden="true">
                          ⌄
                        </span>
                      </div>
                    </button>
                    <div className="detail" id={`d${i}`}>
                      <div>
                        <div className="in">
                          {(p.url || p.githubUrl) && (
                            <div className="proj-actions">
                              {p.url && (
                                <a
                                  href={p.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="proj-link-btn"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  Visit Website ↗{' '}
                                  <span className="url-hint">
                                    ({p.url.replace(/^https?:\/\//, '').replace(/\/$/, '')})
                                  </span>
                                </a>
                              )}
                              {p.githubUrl && (
                                <a
                                  href={p.githubUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="proj-link-btn secondary"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <svg
                                    width="15"
                                    height="15"
                                    viewBox="0 0 24 24"
                                    fill="currentColor"
                                    style={{ marginRight: '6px' }}
                                  >
                                    <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                                  </svg>
                                  View on GitHub ↗
                                </a>
                              )}
                            </div>
                          )}
                          <ul>
                            {p.d.map((desc, di) => (
                              <li key={di}>{desc}</li>
                            ))}
                          </ul>
                          <div className="stack">{p.t}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Scale Section */}
        <section id="scale">
          <div className="wrap">
            <h2>Built to grow to 1 million users</h2>
            <p className="lead" style={{ margin: '-10px 0 24px' }}>
              Drag the slider to see how I design system architecture at each stage of growth, backed by real-world high-traffic deployments.
            </p>

            {/* Real-World Scaling Milestones */}
            <div className="scale-milestones">
              <div className="milestone-card">
                <span className="badge-text">⚡ 2025 Live Production Milestone</span>
                <h4>Bingotingo – Scaled to 1 Million Users</h4>
                <p>
                  Engineered for massive traffic spikes in 2025 with full-page caching, optimized SQL queries, and CDN edge delivery at{' '}
                  <a
                    href="https://bingotingo.mahashankh.org"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ textDecoration: 'underline', fontWeight: 600 }}
                  >
                    bingotingo.mahashankh.org
                  </a>
                  .
                </p>
              </div>
              <div className="milestone-card">
                <span className="badge-text">⚡ Generative AI Commercial Milestone</span>
                <h4>AJUPY AI – Generated 5 Lakhs in 1st 6 Months</h4>
                <p>
                  Architected image generative AI pipelines and textile design workflows at{' '}
                  <a
                    href="https://ajupy.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ textDecoration: 'underline', fontWeight: 600 }}
                  >
                    ajupy.com
                  </a>
                  ; generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.
                </p>
              </div>
            </div>

            <div className="panel">
              <label htmlFor="sr" className="stack">
                Registered users
              </label>
              <div className="big" id="su">
                {currentTier.l}
              </div>
              <input
                type="range"
                id="sr"
                min="0"
                max="4"
                step="1"
                value={scaleTierIndex}
                onChange={(e) => setScaleTierIndex(Number(e.target.value))}
                aria-describedby="sl"
              />
              <div className="bar">
                <i id="sb" style={{ width: `${progressPercent}%` }} />
              </div>
              <ul id="sl" className="slist">
                {currentTier.t.map((point, pi) => (
                  <li key={pi}>{point}</li>
                ))}
              </ul>
              <p className="stack" style={{ margin: '14px 0 0' }}>
                Architecture progression model illustrating how database splitting, caching hierarchies, and asynchronous worker pipelines scale from single-server setups to million-user infrastructure.
              </p>
            </div>
          </div>
        </section>

        {/* Timeline & Experience Section */}
        <section id="timeline">
          <div className="wrap">
            <h2>Experience &amp; Timeline</h2>
            <p className="lead" style={{ margin: '-10px 0 36px' }}>
              Key technical roles, founder initiatives, and scaling milestones from 2019 to present.
            </p>

            <div className="two">
              {/* Vertical Timeline */}
              <div className="timeline">
                {/* Item 1: AJUPY AI */}
                <div className="timeline-item">
                  <div className="timeline-dot active" aria-hidden="true" />
                  <div className="timeline-card">
                    <div className="timeline-header">
                      <h3 style={{ fontSize: '20px' }}>Founder</h3>
                      <span className="timeline-date">⚡ 2025 – Present</span>
                    </div>
                    <div className="timeline-company">
                      <b>AJUPY AI</b> · Image Generative AI Platform (
                      <a
                        href="https://ajupy.com"
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ textDecoration: 'underline', color: 'var(--accent)' }}
                      >
                        ajupy.com
                      </a>
                      )
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                      <span className="scale-pill">⚡ Generated 5 Lakhs in 1st 6 Months</span>
                    </div>
                    <ul className="timeline-bullets">
                      <li>
                        Founded and led the architectural development of the image generative AI platform; generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.
                      </li>
                      <li>
                        Architected asynchronous generation pipelines, queue workers, quota enforcement, and multi-tier subscription workflows.
                      </li>
                      <li>
                        Implemented intelligent AI model failover routing, fashion/visual workflows, and scalable cloud deployment.
                      </li>
                    </ul>
                    <div className="stack">React · TypeScript · Generative AI APIs · Scalable Queues · Cloud Deployment</div>
                  </div>
                </div>

                {/* Item 2: Mahashankh Design & Technology */}
                <div className="timeline-item">
                  <div className="timeline-dot" aria-hidden="true" />
                  <div className="timeline-card">
                    <div className="timeline-header">
                      <h3 style={{ fontSize: '20px' }}>Technology Product Developer</h3>
                      <span className="timeline-date">2019 – 2025</span>
                    </div>
                    <div className="timeline-company">
                      <b>Mahashankh Design &amp; Technology</b> · Web Systems &amp; Digital Platforms
                    </div>
                    <div style={{ marginBottom: '10px' }}>
                      <span className="scale-pill">⚡ Bingotingo scaled to 1 Million Users in 2025</span>
                    </div>
                    <ul className="timeline-bullets">
                      <li>
                        Engineered high-concurrency WordPress platforms, plugin concepts, and business-critical web systems.
                      </li>
                      <li>
                        Engineered Bingotingo (
                        <a
                          href="https://bingotingo.mahashankh.org"
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ textDecoration: 'underline' }}
                        >
                          bingotingo.mahashankh.org
                        </a>
                        ), scaling to 1 Million users in 2025 with zero downtime via database indexing and edge caching.
                      </li>
                      <li>
                        Developed Canvasroom (
                        <a
                          href="https://canvasroom.space"
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ textDecoration: 'underline' }}
                        >
                          canvasroom.space
                        </a>
                        ), a live 3D presentation platform for interior designers, wallpaper dealers &amp; real estate with auto voice agent walkthroughs and room scanning furniture installation.
                      </li>
                      <li>
                        Full software lifecycle ownership: requirement analysis, security audits, performance profiling, and production ops.
                      </li>
                    </ul>
                    <div className="stack">WordPress · PHP 7/8 · MySQL · REST APIs · CDN Caching · Linux · Security</div>
                  </div>
                </div>

                {/* Item 3: Education */}
                <div className="timeline-item">
                  <div className="timeline-dot" aria-hidden="true" />
                  <div className="timeline-card">
                    <div className="timeline-header">
                      <h3 style={{ fontSize: '20px' }}>B.Tech in Computer Science Engineering</h3>
                      <span className="timeline-date">2022 – 2026</span>
                    </div>
                    <div className="timeline-company">
                      <b>NIMS University, Jaipur</b> · Class of 2026
                    </div>
                    <ul className="timeline-bullets">
                      <li>
                        Computer Science coursework focusing on Data Structures &amp; Algorithms, Database Systems (SQL), Operating Systems, and Distributed Computing.
                      </li>
                      <li>
                        Combined rigorous engineering coursework with practical commercial platform delivery for high-traffic environments.
                      </li>
                    </ul>
                    <div className="stack">Data Structures · Algorithms · Database Design · Secure Systems</div>
                  </div>
                </div>
              </div>

              {/* Roles & Competencies Panel */}
              <div>
                <div className="panel" style={{ marginBottom: '24px' }}>
                  <h3 style={{ marginBottom: '14px' }}>Roles I’m after</h3>
                  <div className="roles" id="roles">
                    {rolesList.map((role) => (
                      <span key={role} className="skill">
                        {role}
                      </span>
                    ))}
                  </div>
                  <p className="stack" style={{ marginTop: '22px' }}>
                    Currently strengthening: data structures and algorithms, SQL, testing, CI/CD, secure coding.
                  </p>
                </div>

                <div className="panel">
                  <h3 style={{ marginBottom: '16px' }}>Core Competencies</h3>
                  <div className="principle">
                    <b>High-Concurrency Scaling</b>Proven track record scaling web platforms to 1 Million users (Bingotingo) and generating 5 Lakhs in 1st 6 Months with Major client Companies of textile industries (AJUPY AI).
                  </div>
                  <div className="principle">
                    <b>Full Lifecycle Ownership</b>From architecture and schema design to UI development, automated API queues, deployment, and ongoing optimization.
                  </div>
                  <div className="principle" style={{ margin: 0 }}>
                    <b>Pragmatic Engineering</b>Writing clean, maintainable, secure code that solves real business and user problems without unnecessary bloat.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Skills & Specializations Section: Divided into WordPress Developer and AI Developer */}
        <section id="skills">
          <div className="wrap">
            <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '16px', marginBottom: '28px' }}>
              <div>
                <h2>Skills &amp; Specializations</h2>
                <p className="lead" style={{ margin: '8px 0 0' }}>
                  Divided into two core technical disciplines: WordPress &amp; PHP engineering, and Generative AI platform development.
                </p>
              </div>

              {/* Track Switcher */}
              <div className="skill-tab-bar" role="group" aria-label="Select skills track">
                <button
                  type="button"
                  className="chip"
                  aria-pressed={activeDevTrack === 'both'}
                  onClick={() => setActiveDevTrack('both')}
                >
                  ✨ Both Tracks (Side-by-Side)
                </button>
                <button
                  type="button"
                  className="chip"
                  aria-pressed={activeDevTrack === 'wordpress'}
                  onClick={() => setActiveDevTrack('wordpress')}
                >
                  💻 WordPress Developer
                </button>
                <button
                  type="button"
                  className="chip"
                  aria-pressed={activeDevTrack === 'ai'}
                  onClick={() => setActiveDevTrack('ai')}
                >
                  🤖 AI Developer
                </button>
              </div>
            </div>

            {/* Divided Two Developer Sections */}
            <div className="dev-sections-container">
              {/* 1. WordPress Developer Section */}
              {(activeDevTrack === 'both' || activeDevTrack === 'wordpress') && (
                <div id="wordpress-skills" className="dev-pillar-card wp">
                  <div className="dev-pillar-header">
                    <span className="pillar-badge">{wordpressDeveloperTrack.badge}</span>
                    <h3>💻 {wordpressDeveloperTrack.title}</h3>
                    <p>{wordpressDeveloperTrack.description}</p>
                    <div style={{ marginTop: '4px' }}>
                      <span className="scale-pill">{wordpressDeveloperTrack.milestone}</span>
                    </div>
                  </div>

                  {wordpressDeveloperTrack.groups.map((group) => (
                    <div key={group.category} className="dev-pillar-group">
                      <h4>
                        <span>▸</span> {group.category}
                      </h4>
                      <div className="dev-pillar-chips">
                        {group.skills.map((skill) => (
                          <span key={skill} className="dev-skill-chip">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 2. AI Developer Section */}
              {(activeDevTrack === 'both' || activeDevTrack === 'ai') && (
                <div id="ai-skills" className="dev-pillar-card ai">
                  <div className="dev-pillar-header">
                    <span className="pillar-badge">{aiDeveloperTrack.badge}</span>
                    <h3>🤖 {aiDeveloperTrack.title}</h3>
                    <p>{aiDeveloperTrack.description}</p>
                    <div style={{ marginTop: '4px' }}>
                      <span className="scale-pill">{aiDeveloperTrack.milestone}</span>
                    </div>
                  </div>

                  {aiDeveloperTrack.groups.map((group) => (
                    <div key={group.category} className="dev-pillar-group">
                      <h4>
                        <span>▸</span> {group.category}
                      </h4>
                      <div className="dev-pillar-chips">
                        {group.skills.map((skill) => (
                          <span key={skill} className="dev-skill-chip">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about">
          <div className="wrap two">
            <div>
              <h2>About</h2>
              <p>
                I’m a developer and product builder. From 2019 to 2025, I turned business requirements into
                working software at Mahashankh Design &amp; Technology: high-traffic WordPress sites, custom plugins,
                API integrations, and scalable web platforms.
              </p>
              <p>
                In 2025, I founded AJUPY AI, leading the architecture and technical development of an image generative
                AI platform; generated 5 Lakhs in 1st 6 Months with Major client Companies of textile industries.
              </p>
              <p>
                I like owning the full path: understanding what a feature is for, designing it, building it,
                debugging it and improving it after people use it.
              </p>
              <p>
                Now I want to join an engineering team, work with experienced developers, and keep
                strengthening my computer science fundamentals.
              </p>
            </div>
            <div className="panel">
              <h3 style={{ marginBottom: '18px' }}>How I work</h3>
              <div className="principle">
                <b>Secure by default</b>Validate input, escape output, protect credentials, check permissions.
              </div>
              <div className="principle">
                <b>Reliable</b>Handle errors, validate API responses, test the important flows.
              </div>
              <div className="principle">
                <b>Maintainable</b>Clear naming, modular code, documentation.
              </div>
              <div className="principle" style={{ margin: 0 }}>
                <b>User focused</b>Build what people need, not extra complexity.
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact">
          <div className="wrap">
            <div className="contact">
              <h2>Let’s build something reliable.</h2>
              <p>
                I’m available for software development roles across India, subject to interview and joining
                arrangements.
              </p>
              <div className="clinks">
                <button className="p" id="copy" onClick={handleCopyEmail}>
                  {copyEmailText}
                </button>
                <a href="mailto:opspj0001@gmail.com">Send an email</a>
                <a href="https://github.com/opspj007" target="_blank" rel="noopener noreferrer">
                  GitHub
                </a>
                <a
                  href="https://www.linkedin.com/in/om-prakash-chaudhary-nims/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  LinkedIn
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer & Message Section */}
      <footer id="message">
        <div className="wrap">
          <div className="two">
            <div>
              <h2 style={{ fontSize: '30px' }}>Message me</h2>
              <p>Have a role, project or question? Send a note and I’ll reply by email.</p>
              <p style={{ margin: 0 }}>
                <a href="mailto:opspj007@gmail.com">
                  <b>opspj007@gmail.com</b>
                </a>
              </p>
              <p style={{ margin: '4px 0 0' }}>
                <a href="https://github.com/opspj007" target="_blank" rel="noopener noreferrer">
                  GitHub
                </a>{' '}
                ·{' '}
                <a
                  href="https://www.linkedin.com/in/om-prakash-chaudhary-nims/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  LinkedIn
                </a>
              </p>
            </div>
            {isSubmitted && submittedInfo ? (
              <div className="msg-success-box" role="status">
                <div className="msg-success-header">
                  <span style={{ fontSize: '20px' }}>✅</span>
                  <span>Message Submitted Successfully!</span>
                </div>
                <p>
                  Thank you, <b>{submittedInfo.name}</b>! Your message has been submitted. I will review it and reply directly to{' '}
                  <b>{submittedInfo.email}</b>.
                </p>
                <div
                  style={{
                    background: 'var(--surface)',
                    padding: '12px 14px',
                    borderRadius: '8px',
                    border: '1px solid var(--line)',
                    marginTop: '2px',
                  }}
                >
                  <div
                    style={{
                      fontSize: '12px',
                      color: 'var(--muted)',
                      marginBottom: '4px',
                      fontFamily: 'var(--mono)',
                    }}
                  >
                    Submitted at {submittedInfo.timestamp}:
                  </div>
                  <div
                    style={{
                      fontSize: '14px',
                      color: 'var(--ink)',
                      whiteSpace: 'pre-wrap',
                      fontStyle: 'italic',
                    }}
                  >
                    "{submittedInfo.message}"
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '6px' }}>
                  <button
                    type="button"
                    className="btn p"
                    style={{ fontSize: '13.5px', padding: '8px 16px' }}
                    onClick={() => {
                      setIsSubmitted(false);
                      setSubmittedInfo(null);
                    }}
                  >
                    Send Another Message
                  </button>
                  <a
                    href={`mailto:opspj007@gmail.com?subject=${encodeURIComponent(
                      'Message from ' + submittedInfo.name
                    )}&body=${encodeURIComponent(
                      submittedInfo.message + '\n\nFrom: ' + submittedInfo.name + ' <' + submittedInfo.email + '>'
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn"
                    style={{ fontSize: '13.5px', padding: '8px 16px' }}
                  >
                    Open Mail Client ↗
                  </a>
                </div>
              </div>
            ) : (
              <form className="msg" id="mf" onSubmit={handleSendMessage} noValidate>
                <label htmlFor="mn">
                  Your name
                  <input
                    id="mn"
                    autoComplete="name"
                    value={messageName}
                    onChange={(e) => {
                      setMessageName(e.target.value);
                      if (messageError) setMessageError('');
                    }}
                    placeholder="e.g. Alex Sharma"
                    required
                  />
                </label>
                <label htmlFor="me">
                  Your email
                  <input
                    id="me"
                    type="email"
                    autoComplete="email"
                    value={messageEmail}
                    onChange={(e) => {
                      setMessageEmail(e.target.value);
                      if (messageError) setMessageError('');
                    }}
                    placeholder="e.g. alex@example.com"
                    required
                  />
                </label>
                <label htmlFor="mm">
                  Message
                  <textarea
                    id="mm"
                    rows={4}
                    value={messageText}
                    onChange={(e) => {
                      setMessageText(e.target.value);
                      if (messageError) setMessageError('');
                    }}
                    placeholder="Tell me about your project, team, or opportunity..."
                    required
                  />
                </label>

                {messageError && (
                  <div className="msg-error-box" role="alert">
                    ⚠️ {messageError}
                  </div>
                )}

                <button
                  className="btn p"
                  id="ms"
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <span className="btn-spinner" /> Submitting...
                    </>
                  ) : (
                    'Send message'
                  )}
                </button>
              </form>
            )}
          </div>
          <p style={{ marginTop: '30px' }}>© 2026 Om Prakash Chaudhary · opchaudhary.online</p>
        </div>
      </footer>
    </>
  );
}
